<script setup>
import {Portal} from "vue3-mount";
</script>

<template>
  <Portal name="alerts"/>
  <NuxtLayout>
    <NuxtPage/>
  </NuxtLayout>
</template>


<style lang="scss">
html { scroll-behavior: smooth; }

.jump-enter-active,
.jump-leave-active,
.jump-enter-active,
.jump-leave-active {
  transition: all 0.25s ease-in-out;
}
.jump-enter-from,
.jump-leave-to {
  opacity: 0;
  filter: blur(1rem);
  transform: translateY(-100px);
}
</style>