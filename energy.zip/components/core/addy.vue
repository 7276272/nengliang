<script setup lang="ts">
const props = defineProps({
  address: String,
  avatar: {
    type: String,
    default: `<svg xmlns="http://www.w3.org/2000/svg" x="0" y="0" height="24" width="24"><rect x="0" y="0" rx="0" ry="0" height="24" width="24" transform="translate(2.3090834993278073 5.26468671594718) rotate(100.8 12 12)" fill="#fc193e"></rect><rect x="0" y="0" rx="0" ry="0" height="24" width="24" transform="translate(-0.2447352934152394 -15.912074477655239) rotate(298.0 12 12)" fill="#fc9d00"></rect><rect x="0" y="0" rx="0" ry="0" height="24" width="24" transform="translate(15.958049239056859 -1.4715624425524665) rotate(383.0 12 12)" fill="#f3e800"></rect><rect x="0" y="0" rx="0" ry="0" height="24" width="24" transform="translate(1.3518794530198182 26.944925041666426) rotate(260.4 12 12)" fill="#01728c"></rect></svg>`
  }
})

const addy = computed(() => {
  return props.address.substring(0, 6) + '...' + props.address.substring(props.address.length - 6, 6);
})
</script>

<template>
  <div class="inline-flex px-2.5 py-1.5 text-[12px] rounded-full bg-black/20 items-center">
    <span>{{addy}}</span>
    <div class="ms-2 rounded-full w-6 h-6 overflow-hidden" v-html="props.avatar"></div>
  </div>
</template>