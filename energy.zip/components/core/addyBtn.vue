<script setup>
import Addy from "~/components/core/addy.vue";

const walletStore = useMainPageWallet();
</script>

<template>
  <div class="p-0.5 bg-bgPanel rounded-lg flex flex-row items-center justify-center">
    <span class="text-[14px] text-white font-medium">0.0 ETH</span>
    <addy
        class="ms-6 mt-0.5"
        :avatar="walletStore.wallet.avatar"
        :address="walletStore.wallet.address"/>
  </div>
</template>