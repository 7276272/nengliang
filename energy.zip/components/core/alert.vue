<script setup lang="ts">
import {getNode, vMount} from "vue3-mount"
import {gsap} from 'gsap'
const unmount = getNode()
const shown = ref(true);
const props = defineProps({
  type: {
    type: String,
    default: 'success'
  },

  expireDuration: {
    type: Number,
    default: 2500,
  },

  expire: {
    type: Boolean,
    default: true
  },

  content: String,
  close: Function,
})

onMounted(() => {
  if(props.expire) {
    setTimeout(() => {
      shown.value = false;
      setTimeout(() => {
        onClose()
      }, 300)
    }, props.expireDuration as Number)
  }
})

const onClose = () => {
  props.close()
  unmount()
}

const afterEnterAnim = (el) => {
  if(props.type == 'error') {
    let tl = gsap.timeline();
    tl.to(el,
        {
          translateX: '-10px',
          duration: 0.1
        }
    )
    tl.to(el,
        {
          translateX: '10px',
          duration: 0.1
        }
    )

    tl.to(el,
        {
          translateX: '0',
          duration: 0.1
        }
    )
  }
}

</script>
<template>
  <div class="absolute items-end bottom-4 w-screen flex justify-center z-[9999]">
  <transition
      mode="out-in"
      appear
      enter-active-class="transition duration-[200ms] ease-in-out"
      leave-active-class="transition duration-[200ms] ease-in-out"
      enter-from-class="opacity-0"
      leave-to-class="opacity-0"
      @after-enter="afterEnterAnim"
  >
  <div v-mount v-if="shown" class="w-full max-w-max">
    <div
        @click="onClose"
        class="cursor-pointer hover:opacity-70 active:scale-95 relative h-fit px-6 py-5 bg-bgPanel rounded-full border border-neutral-600 text-text-color flex flex-row justify-center items-center self-end mb-24 w-full">
      <svg
          v-if="props.type === 'error'"
          class="text-red-400 mt-0.5 basis-[10%]"
          xmlns="http://www.w3.org/2000/svg" width="24"  height="24"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="3"  stroke-linecap="round"  stroke-linejoin="round" ><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M18 6l-12 12" /><path d="M6 6l12 12" /></svg>

      <svg
          v-if="props.type === 'success'"
          class="text-green-400 mt-0.5 basis-[10%]"
          xmlns="http://www.w3.org/2000/svg"  width="24"  height="24"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="3"  stroke-linecap="round"  stroke-linejoin="round" ><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l5 5l10 -10" /></svg>

      <svg
          v-if="props.type === 'loading'"
          class="text-text-color mt-0.5"
          fill="#fff" width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M10.14,1.16a11,11,0,0,0-9,8.92A1.59,1.59,0,0,0,2.46,12,1.52,1.52,0,0,0,4.11,10.7a8,8,0,0,1,6.66-6.61A1.42,1.42,0,0,0,12,2.69h0A1.57,1.57,0,0,0,10.14,1.16Z"><animateTransform attributeName="transform" type="rotate" dur="0.75s" values="0 12 12;360 12 12" repeatCount="indefinite"/></path></svg>

      <span
          v-if="props.type != 'loading'"
          class="ms-4 text-md text-white w-full">{{props.content}}</span>
    </div>
  </div>
  </transition>
  </div>
</template>