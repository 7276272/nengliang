<script setup lang="ts">
import { Menu, MenuButton, MenuItems, MenuItem } from '@headlessui/vue'
import {useField} from "vee-validate";
const model = defineModel()

const props = defineProps({
  name: String,
  values: Array,
  placeholder: String,
})

const { value, errorMessage } = useField(() => props.name);

const handleChange = (val) => {
  value.value = val;
  model.value = val
}

</script>


<template>
  <Menu as="div" class="relative inline-block text-left">
    <div>
      <MenuButton
          v-slot="{open}"
          :class="{'text-textSecondary/40 text-[15px]' : !value}"
          class="bg-bgPanelInput rounded-lg border border-white/[12%] hover:border-white/20  transition inline-flex justify-between px-5 text-text-color py-4 text-[13px] w-full focus-visible:outline-none focus-within:border-accent-text-color visited:border-accent-text-color target:border-accent-text-color active:border-accent-text-color focus-visible:border-accent-text-color focus:border-accent-text-color"
      >
        {{value || props.placeholder}}

        <transition
          mode="out-in"
          enter-active-class="transition duration-[150ms] ease-in-out"
          leave-active-class="transition duration-[150ms] ease-in-out"
          enter-from-class="blur-[3px]"
          leave-to-class="blur-[3px]"
        >
        <svg v-if="!open" xmlns="http://www.w3.org/2000/svg"  width="21"  height="21"  viewBox="0 0 24 24"  fill="none"  stroke="white"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="icon icon-tabler icons-tabler-outline icon-tabler-chevron-down"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M6 9l6 6l6 -6" /></svg>
        <svg v-else xmlns="http://www.w3.org/2000/svg"  width="21"  height="21"  viewBox="0 0 24 24"  fill="none"  stroke="white"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="icon icon-tabler icons-tabler-outline icon-tabler-chevron-up"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M6 15l6 -6l6 6" /></svg>
        </transition>
      </MenuButton>
    </div>

    <transition
        enter-active-class="transition duration-100 ease-out"
        enter-from-class="transform scale-95 opacity-0"
        enter-to-class="transform scale-100 opacity-100"
        leave-active-class="transition duration-75 ease-in"
        leave-from-class="transform scale-100 opacity-100"
        leave-to-class="transform scale-95 opacity-0"
    >
      <MenuItems
          class="menuContainer z-[1100] absolute right-0 mt-2 w-56 origin-top-right border border-white/[12%] rounded-md bg-bgPanelInput shadow-lg ring-1 ring-black/5 focus:outline-none max-h-[200px] overflow-y-auto"
      >
        <div v-for="val in props.values" class="px-1 py-1">
          <MenuItem v-slot="{ active }">
            <div
                @click="handleChange(val)"
                :class="[
                  active ? 'text-white' : 'text-neutral-300',
                  'hover:bg-accent-cyan hover:text-button-text-color cursor-pointer group flex w-full items-center rounded-md px-2 py-2 text-sm',
                ]"
            >
              {{val}}
            </div>
          </MenuItem>
        </div>
      </MenuItems>
    </transition>
  </Menu>
</template>

<style lang="scss">
.menuContainer::-webkit-scrollbar-track
{
  background-color: transparent;
}

.menuContainer::-webkit-scrollbar
{
  width: 2px;
  background-color: transparent;
}

.menuContainer::-webkit-scrollbar-thumb
{
  border-radius: 3px;
  background-color: #555;
}
</style>