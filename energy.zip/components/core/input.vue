<script setup lang="ts">
import { gsap } from 'gsap';
import {useField} from "vee-validate";

const inputID = makeUUID(6);

const props = defineProps({
  placeholder: String,
  type: {
    type: String,
    default: "text"
  },
  initialValue: Number,
  name: String,
  label: String,
})

const { value, errorMessage } = useField(() => props.name, undefined, {
  initialValue: props?.initialValue,
  label: props.label
});

const placeholder$El = ref<HTMLSpanElement|null>(null);
const inputFocus = ref(false);

const handleFocusIn = () => {
  inputFocus.value = true;
  if(!placeholder$El) return
  if(value.value) return

  gsap.fromTo(placeholder$El.value, {
        scale: 1,
      },
      {
        y: -12,
        x: -placeholder$El.value.innerHTML.length + 3,
        scale: 0.75,
        duration: 0.2,
        ease: 'power1.inOut'
      }
  )
}

const handleFocusOut = () => {
  inputFocus.value = false;
  if(!placeholder$El) return
  if(value.value == 0) value.value = null
  if(value.value) return


  gsap.fromTo(placeholder$El.value, {
        y: -12,
        x: -placeholder$El.value.innerHTML.length + 3,
        scale: 0.75,
      },
      {
        y: 0,
        x: 0,
        scale: 1,
        duration: 0.2,
        ease: 'power1.inOut'
      }
  )
}

</script>

<template>
  <div class="inline-flex items-center relative w-full">
    <span class="absolute">
      <slot name="icon"/>
    </span>

    <label
        :for="inputID"
        ref="placeholder$El"
        :class="inputFocus ? 'text-accent-cyan' : 'text-textSecondary/40'"
        class="cursor-text ml-14 absolute text-[15px]">
      {{props.placeholder}}
    </label>

    <button
        v-if="props.type === 'number'"
        @click="emit('max')"
      class="right-4 absolute py-2 px-4 text-[10px] font-medium text-accent-cyan bg-accent-cyan/10 hover:bg-accent-cyan/20 rounded-md"
    >
      MAX
    </button>

    <input
          :id="inputID"
          :name="props.name"
          :type="props.type"
          @focusin="handleFocusIn"
          @blur="handleFocusOut"
          v-model="value"
           class="bg-bgPanelInput pt-6 pb-3 px-14 text-sm rounded-lg border border-white/[12%] hover:border-white/20 transition w-full focus-visible:outline-none focus-visible:border-white/30 focus:border-white/30"/>
  </div>
</template>

<style lang="scss" scoped>
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* Firefox */
input[type=number] {
  -moz-appearance: textfield;
}
</style>