<script setup lang="ts">
import { gsap } from 'gsap';

const props = defineProps({
  values: Array,
})

const model = defineModel();
const coverEl = ref<HTMLDivElement|null>(null);

const toggle = (v) => {
  let coverWidth : Number = coverEl.value?.offsetWidth;

  if(model.value == props.values[0]) {
    model.value = props.values[1];

    gsap.fromTo(coverEl.value, {
      left: 0,
    }, {
      left: coverWidth + 2,
      duration: 0.3,
      ease: "power1.inOutn"
    })
  }
  else {
    model.value = props.values[0];

    gsap.fromTo(coverEl.value, {
      left: coverWidth - 2
    }, {
      left: 0,
      duration: 0.3,
      ease: "power1.inOutn"
    })
  }
}
</script>

<template>
  <div class="inline-flex flex-row items-center bg-[#121217] rounded-full p-[1px] overflow-hidden relative">
    <div ref="coverEl" class="bg-[#35353D] left-0 top-0 mt-[2px] ml-[2px] w-[calc(50%-3px)] h-[calc(100%-4px)] rounded-full absolute"></div>
    <button @click="toggle(props.values[0])"
            :class="model === props.values[0] ? 'text-white' : 'text-white/40'"
            class="z-10 rounded-full px-10 py-3 text-[14px] font-medium">{{ props.values[0] }}</button>
    <button @click="toggle(props.values[1])"
            :class="model === props.values[1] ? 'text-white' : 'text-white/40'"
            class="transition z-10 rounded-full px-10 py-3 text-[14px] font-medium">{{ props.values[1]}}</button>
  </div>
</template>
<script setup lang="ts">
</script>