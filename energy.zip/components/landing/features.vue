<template>
  <div class="w-full after:absolute after:left-0 after:bottom-0 after:w-full after:h-[1px] after:bg-section-splitter relative flex justify-center">
    <div class="absolute -top-[350px] -left-[650px] bg-splash6 w-[1400px] h-[1400px] rounded-full"></div>
    <div class="px-20 py-44 2xl:max-w-screen-2xl xl:max-w-screen-md max-w-screen-sm justify-self-center w-full">
      <div class="w-full flex justify-center items-center flex-col mb-12">
        <span class="text-2xl font-medium">How it works?</span>
        <span class="text-[3rem] font-bold">It's Simple!</span>
      </div>

  <!--    2xl and up-->
      <div class="hidden 2xl:flex flex-col">
        <div class="flex flex-row items-center">
          <div class="basis-[28%] before:absolute before:left-0 before:w-[500px] before:h-[1px] before:bg-section-splitter after:w-[300px] after:absolute after:h-[1px] after:bg-black flex items-center relative">
            <div class="bg-bg1 z-10 flex justify-center items-center rounded-full border border-section-splitter w-[110px] h-[110px]">
              <svg  xmlns="http://www.w3.org/2000/svg"  width="40px"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="icon icon-tabler icons-tabler-outline icon-tabler-wallet"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M17 8v-3a1 1 0 0 0 -1 -1h-10a2 2 0 0 0 0 4h12a1 1 0 0 1 1 1v3m0 4v3a1 1 0 0 1 -1 1h-12a2 2 0 0 1 -2 -2v-12" /><path d="M20 12v4h-4a2 2 0 0 1 0 -4h4" /></svg>
            </div>
          </div>

          <div class="basis-[40%] before:absolute before:left-0 before:w-[600px] before:h-[1px] before:bg-section-splitter after:w-[400px] after:absolute after:h-[1px] after:bg-black flex items-center relative">
            <div class="bg-bg1 z-10 flex justify-center items-center rounded-full border border-section-splitter w-[110px] h-[110px]">
              <svg  xmlns="http://www.w3.org/2000/svg"  width="40px" viewBox="0 0 24 24"  fill="currentColor"  class="icon icon-tabler icons-tabler-filled icon-tabler-bolt"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M13 2l.018 .001l.016 .001l.083 .005l.011 .002h.011l.038 .009l.052 .008l.016 .006l.011 .001l.029 .011l.052 .014l.019 .009l.015 .004l.028 .014l.04 .017l.021 .012l.022 .01l.023 .015l.031 .017l.034 .024l.018 .011l.013 .012l.024 .017l.038 .034l.022 .017l.008 .01l.014 .012l.036 .041l.026 .027l.006 .009c.12 .147 .196 .322 .218 .513l.001 .012l.002 .041l.004 .064v6h5a1 1 0 0 1 .868 1.497l-.06 .091l-8 11c-.568 .783 -1.808 .38 -1.808 -.588v-6h-5a1 1 0 0 1 -.868 -1.497l.06 -.091l8 -11l.01 -.013l.018 -.024l.033 -.038l.018 -.022l.009 -.008l.013 -.014l.04 -.036l.028 -.026l.008 -.006a1 1 0 0 1 .402 -.199l.011 -.001l.027 -.005l.074 -.013l.011 -.001l.041 -.002z" /></svg>
            </div>
          </div>

          <div class="flex flex-row items-center">
            <div class="bg-bg1 z-10 flex justify-center items-center rounded-full border border-section-splitter w-[110px] h-[110px]">
              <svg  xmlns="http://www.w3.org/2000/svg"  width="40px"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="icon icon-tabler icons-tabler-outline icon-tabler-zoom-scan"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 8v-2a2 2 0 0 1 2 -2h2" /><path d="M4 16v2a2 2 0 0 0 2 2h2" /><path d="M16 4h2a2 2 0 0 1 2 2v2" /><path d="M16 20h2a2 2 0 0 0 2 -2v-2" /><path d="M8 11a3 3 0 1 0 6 0a3 3 0 0 0 -6 0" /><path d="M16 16l-2.5 -2.5" /></svg>
            </div>

            <div class="-ml-5 bg-bg1 z-10 flex justify-center items-center rounded-full border border-section-splitter w-[110px] h-[110px]">
              <svg  xmlns="http://www.w3.org/2000/svg"  width="40px"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="icon icon-tabler icons-tabler-outline icon-tabler-checkbox"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 11l3 3l8 -8" /><path d="M20 12v6a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2h9" /></svg>
            </div>

            <div class="-ml-5 bg-bg1 z-10 flex justify-center items-center rounded-full border border-section-splitter w-[110px] h-[110px]">
              <svg  xmlns="http://www.w3.org/2000/svg"  width="40px"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="icon icon-tabler icons-tabler-outline icon-tabler-charging-pile"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M18 7l-1 1" /><path d="M14 11h1a2 2 0 0 1 2 2v3a1.5 1.5 0 0 0 3 0v-7l-3 -3" /><path d="M4 20v-14a2 2 0 0 1 2 -2h6a2 2 0 0 1 2 2v14" /><path d="M9 11.5l-1.5 2.5h3l-1.5 2.5" /><path d="M3 20l12 0" /><path d="M4 8l10 0" /></svg>
            </div>
          </div>
        </div>

        <div class="flex flex-row items-center py-5 tracking-widest leading-tight gap-x-12">
          <div class="basis-[25%] flex flex-col ">
            <span class="text-[2rem] font-normal">Connect Your Wallet</span>
          </div>

          <div class="basis-[35%] flex flex-col">
            <span class="text-[2rem] font-normal">Select</span>
            <span class="text-[2rem] font-normal">Energy amount and rent duration</span>
          </div>

          <div class="flex flex-col">
            <span class="text-[2rem] font-normal">Review</span>
            <span class="text-[2rem] font-normal">and confirm to complete</span>
          </div>
        </div>
      </div>

  <!--    xl and down-->

      <div class="flex 2xl:hidden flex-row space-x-16">
        <div class="flex flex-col h-[600px]">
          <div class="basis-[40%] relative flex justify-center before:absolute before:w-[1px] before:h-[250px] before:bg-section-splitter after:w-[1px] after:absolute after:h-[160px] before:z-[1] after:z-[2] after:bg-black flex">
            <div class="bg-bg1 z-10 flex justify-center items-center rounded-full border border-section-splitter w-[90px] h-[90px]">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 80 80" class="w-[60px] h-[60px]"><g fill="#000" clip-path="url(#i81)"><path d="m39.706 33.053-16.373 7.446 16.373 9.673 16.366-9.673-16.366-7.447Z" opacity="0.6"></path><path d="m23.333 40.499 16.373 9.673V13.333L23.333 40.5Z" opacity="0.45"></path><path d="M39.7 13.333v36.839l16.367-9.673L39.7 13.333Z" opacity="0.8"></path><path d="m23.333 43.601 16.373 23.066V53.274L23.333 43.6Z" opacity="0.45"></path><path d="M39.7 53.273v13.393L56.08 43.6 39.7 53.273Z" opacity="0.8"></path><g filter="url(#i80)" opacity="0.3"><path d="M48.373 32.72 32 40.164l16.373 9.673 16.366-9.673-16.366-7.446Z" opacity="0.6"></path><path d="m32 40.166 16.373 9.673V13L32 40.166Z" opacity="0.45"></path><path d="M48.367 13v36.839l16.366-9.673L48.367 13Z" opacity="0.8"></path><path d="m32 43.268 16.373 23.066V52.94L32 43.268Z" opacity="0.45"></path><path d="M48.367 52.94v13.393l16.38-23.066-16.38 9.673Z" opacity="0.8"></path></g></g><defs><clipPath id="i81"><path fill="#fff" d="M0 0h80v80H0z"></path></clipPath><filter id="i80" width="60.746" height="81.334" x="18" y="-1" color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse"><feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend><feGaussianBlur result="effect1_foregroundBlur_40_3652" stdDeviation="7"></feGaussianBlur></filter></defs></svg>
            </div>
          </div>

          <div class="basis-[40%] relative flex justify-center before:absolute before:w-[1px] before:h-[250px] before:bg-section-splitter after:w-[1px] after:absolute after:h-[160px] before:z-[1] after:z-[2] after:bg-black flex">
            <div class="bg-bg1 z-10 flex justify-center items-center rounded-full border border-section-splitter w-[90px] h-[90px]">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 80 80" class="w-[60px] h-[60px]"><g fill="#00A3FF" clip-path="url(#i83)"><g filter="url(#i82)" opacity="0.7"><path d="m53.646 35.868.389.597c4.39 6.735 3.41 15.555-2.357 21.206-3.393 3.324-7.84 4.987-12.286 4.987l14.254-26.79Z" opacity="0.6"></path><path d="m39.39 44.01 14.254-8.142-14.254 26.79V44.01Z" opacity="0.2"></path><path d="m25.122 35.868-.39.597c-4.39 6.735-3.409 15.555 2.358 21.206 3.393 3.324 7.84 4.987 12.286 4.987l-14.254-26.79Z"></path><path d="m39.372 44.01-14.254-8.142 14.254 26.79V44.01Z" opacity="0.6"></path><path d="M39.395 25.821v14.043l12.279-7.017-12.279-7.026Z" opacity="0.2"></path><path d="m39.392 25.821-12.288 7.026 12.288 7.017V25.821Z" opacity="0.6"></path><path d="m39.392 14.011-12.288 18.84 12.288-7.045V14.01Z"></path><path d="m39.395 25.804 12.288 7.046L39.395 14v11.804Z" opacity="0.6"></path></g><path d="m54.767 35.471.403.614c4.546 6.92 3.53 15.984-2.44 21.79C49.215 61.291 44.611 63 40.007 63l14.76-27.529Z" opacity="0.6"></path><path d="m40.006 43.838 14.76-8.367L40.006 63V43.838Z" opacity="0.2"></path><path d="m25.233 35.471-.403.614c-4.546 6.92-3.53 15.984 2.44 21.79C30.785 61.291 35.389 63 39.993 63L25.232 35.47Z"></path><path d="m39.988 43.838-14.76-8.367L39.989 63V43.838Z" opacity="0.6"></path><path d="M40.012 25.147v14.43l12.713-7.21-12.713-7.22Z" opacity="0.2"></path><path d="m40.008 25.147-12.723 7.22 12.723 7.21v-14.43Z" opacity="0.6"></path><path d="m40.008 13.011-12.723 19.36 12.723-7.24v-12.12Z"></path><path d="m40.012 25.13 12.723 7.24L40.012 13v12.13Z" opacity="0.6"></path></g><defs><clipPath id="i83"><rect width="80" height="80" fill="#fff" rx="40"></rect></clipPath><filter id="i82" width="70.768" height="84.658" x="4" y="-4" color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse"><feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend><feGaussianBlur result="effect1_foregroundBlur_40_3677" stdDeviation="9"></feGaussianBlur></filter></defs></svg>
            </div>
          </div>

          <div class="flex flex-col items-center">
            <div class="bg-bg1 z-10 flex justify-center items-center rounded-full border border-section-splitter w-[90px] h-[90px]">
              <img lazy src="@/assets/images/1inch.svg" class="w-[60px] h-[60px]"/>
            </div>

            <div class="-mt-3 bg-bg1 z-10 flex justify-center items-center rounded-full border border-section-splitter w-[90px] h-[90px]">
              <img lazy src="@/assets/images/curve.svg" class="w-[60px] h-[60px]"/>
            </div>

            <div class="-mt-3 bg-bg1 z-10 flex justify-center items-center rounded-full border border-section-splitter w-[90px] h-[90px]">
              <img lazy src="@/assets/images/balancer.svg" class="w-[60px] h-[60px]"/>
            </div>
          </div>
        </div>

        <div class="flex flex-col tracking-widest">
          <div class="basis-[30%] flex flex-col max-w-[250px] mt-2">
            <span class="text-[1.5rem] font-medium">Connect Your Wallet</span>
          </div>

          <div class="basis-[40%] flex flex-col">
            <span class="text-[1.5rem] font-medium">Select energy amount and rent duration</span>
          </div>

          <div class="flex flex-col  ">
            <span class="text-[1.5rem] font-medium">Review and confirm to complete</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
</script>