<script setup lang="ts">
import Header from "~/components/landing/header.vue";
</script>

<template>
  <div class="z-[15] fixed w-screen h-screen backdrop-blur-3xl flex flex-col">
    <div class="2xl:max-w-screen-2xl xl:max-w-screen-md max-w-screen-sm self-center w-full">
      <div class="grid grid-cols-12 gap-x-8 py-44">
        <div class="col-span-5 flex flex-col justify-start w-full">
          <span class="text-4xl text-black font-medium">Energy</span>

          <div class="flex flex-col justify-center items-center mt-8 gap-y-5">
            <div class="transition hover:bg-white cursor-pointer bg-white/50 py-4 px-4 rounded-2xl border border-neutral-200 flex flex-row items-center w-full">
              <span class="font-semibold text-lg basis-80">Buy Energy</span>
              <span class="p-1.5 rounded-full border border-neutral-150 flex items-center justify-center">
            <svg  xmlns="http://www.w3.org/2000/svg"  width="24"  height="24"  viewBox="0 0 24 24"  fill="currentColor"  class="icon icon-tabler icons-tabler-filled icon-tabler-bolt"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M13 2l.018 .001l.016 .001l.083 .005l.011 .002h.011l.038 .009l.052 .008l.016 .006l.011 .001l.029 .011l.052 .014l.019 .009l.015 .004l.028 .014l.04 .017l.021 .012l.022 .01l.023 .015l.031 .017l.034 .024l.018 .011l.013 .012l.024 .017l.038 .034l.022 .017l.008 .01l.014 .012l.036 .041l.026 .027l.006 .009c.12 .147 .196 .322 .218 .513l.001 .012l.002 .041l.004 .064v6h5a1 1 0 0 1 .868 1.497l-.06 .091l-8 11c-.568 .783 -1.808 .38 -1.808 -.588v-6h-5a1 1 0 0 1 -.868 -1.497l.06 -.091l8 -11l.01 -.013l.018 -.024l.033 -.038l.018 -.022l.009 -.008l.013 -.014l.04 -.036l.028 -.026l.008 -.006a1 1 0 0 1 .402 -.199l.011 -.001l.027 -.005l.074 -.013l.011 -.001l.041 -.002z" /></svg>
              </span>
            </div>
          </div>
        </div>

        <div class="flex justify-center">
          <span class="w-[1px] h-[43.79rem] top-0 absolute bg-section-splitter"></span>
        </div>

        <div class="col-span-5 flex flex-col justify-start">
          <span class="text-3xl text-black font-medium">Learn</span>

          <div class="flex flex-col justify-center items-center mt-8 gap-y-3">
            <div class="transition hover:bg-white cursor-pointer bg-white/50 py-6 px-4 rounded-2xl border border-neutral-200 flex flex-row items-center w-full">
              <a href="#home" class="font-semibold text-lg basis-80">Why NAME?</a>
            </div>

            <div class="transition hover:bg-white cursor-pointer bg-white/50 py-6 px-4 rounded-2xl border border-neutral-200 flex flex-row items-center w-full">
              <span class="font-semibold text-lg basis-80">How does it work</span>
            </div>
          </div>
        </div>
    </div>

      <div class="flex justify-center">
        <span class="w-full h-[1px] absolute border border-section-splitter"></span>
      </div>

    </div>
  </div>
</template>
