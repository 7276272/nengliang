<template>
  <div class="after:absolute after:left-0 after:bottom-0 after:w-full after:h-[1px] after:bg-section-splitter relative w-full flex justify-center">
    <div class="justify-around 2xl:max-w-screen-3xl xl:max-w-screen-lg lg:max-w-screen-md max-w-screen-sm justify-self-center w-full flex flex-col 2xl:flex-row">
      <div class="w-full flex justify-center">
        <div class="flex flex-row items-center 2xl:justify-center flex-wrap">
          <div class="2xl:after:flex after:hidden after:h-[100%] after:w-[1px] after:bg-section-splitter after:absolute after:top-0 after:right-0 relative py-16 px-8 min-w-[350px] flex flex-col">
            <span class="text-neutral-800 font-light text-4xl">Energy</span>

            <div class="mt-4 flex flex-col gap-y-4">
              <span class="text-black text-lg cursor-pointer hover:text-neutral-500">Rent Energy</span>
              <span class="text-black text-lg cursor-pointer hover:text-neutral-500">Lend Energy</span>
            </div>
          </div>

          <div class="relative py-16 pl-44 flex flex-col justify-center">
            <span class="text-neutral-800 font-light text-4xl">Learn</span>

            <div class="mt-4 flex flex-col gap-y-4">
              <span class="text-black text-lg cursor-pointer hover:text-neutral-500">Why us?</span>
              <span class="text-black text-lg cursor-pointer hover:text-neutral-500">How it works?</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
</script>