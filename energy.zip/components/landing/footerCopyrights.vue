<template>
  <div class="2xl:max-w-screen-2xl xl:max-w-screen-md max-w-screen-sm justify-self-center w-full">
    <div class="py-6 flex flex-row justify-between items-center">
      <span class="text-3xl tracking-widest font-bold">LOGO</span>

      <div class="inline-flex divide-x divide-neutral-200">
        <span class="hover:text-black cursor-pointer text-lg text-neutral-500 px-6">Privacy Notice</span>
        <span class="hover:text-black cursor-pointer text-lg text-neutral-500 px-6">Terms of Use</span>
      </div>
    </div>
  </div>
</template>