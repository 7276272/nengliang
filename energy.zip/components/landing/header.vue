<script setup lang="ts">
import {onMounted} from 'vue'
import HeaderPopover from "~/components/landing/headerPopover.vue";
import Staking from "~/components/landing/popovers/staking.vue";
import Learn from "~/components/landing/popovers/learn.vue";
const emit = defineEmits(['floatingNavigationClick']);
const props = defineProps({
  "mobileFloating": Boolean
})

const state = reactive({
  floatHidden: true,
  lastYScroll: 0,
  stateChangedCounter: 0,
  floatingNavigation: false,
})


const uiStore = useLandingUIStore();

onMounted(() => {
  let lastFloatHidden = true;
  window.addEventListener('scroll', function ()  {
    const scrollY = window.scrollY || document.documentElement.scrollTop;
    state.floatHidden = (state.lastYScroll < scrollY) || scrollY == 0;

    state.stateChangedCounter = state.floatHidden != lastFloatHidden ? 0 : state.stateChangedCounter + 1

    lastFloatHidden = state.floatHidden;
    state.lastYScroll = scrollY;
  })
})
</script>

<template>
  <div class="h-[90px] w-full absolute">
    <div
        :class="props.mobileFloating ? 'absolute' : (!state.floatHidden ? 'fixed appear' : (state.lastYScroll > 90 && state.stateChangedCounter < 6 ? 'fixed hide' : 'relative'))"
         class="z-[20] w-full border-b-[1px] border-section-splitter backdrop-blur-md flex justify-center pr-10">
      <div
          class="2xl:max-w-screen-2xl w-full py-[22px]">
        <div class="flex flex-row items-center">
          <div
              :class="props.mobileFloating ? 'basis-[95%]' : 'basis-[45%]'"
              class="ml-6">
           <span class="text-3xl tracking-widest font-bold">LOGO</span>
          </div>

          <div v-show="!props.mobileFloating" class="basis-[50%]">
            <div class="hidden 2xl:flex flex-row gap-x-16">
              <a href="#home" class="text-shadow text-lg font-medium cursor-pointer hover:text-accent-ocean transition-all focus-visible:outline-none">Home</a>
              <a href="#why-us" class="text-shadow text-lg font-medium cursor-pointer hover:text-accent-ocean transition-all focus-visible:outline-none">Why NAME?</a>
              <a href="#how-it-works" class="text-shadow text-lg font-medium cursor-pointer hover:text-accent-ocean transition-all focus-visible:outline-none">How does it work</a>
            </div>
          </div>

          <div class="basis-[5%] justify-end align-center flex items-center gap-x-3">
            <NuxtLink
                to="/rent"
              :class="{'opacity-0': props.mobileFloating}"
              :aria-hidden="props.mobileFloating"
              :aria-disabled="props.mobileFloating"
              class="-mt-1 text-shadow text-lg font-bold bg-black rounded-full text-white font-medium px-5 min-w-max py-2.5 transition-colors hover:bg-accent-ocean">
              Rent Energy
            </NuxtLink>

            <button v-show="!props.mobileFloating" @click="uiStore.floatingNavigationOpen = true">
              <svg xmlns="http://www.w3.org/2000/svg"  width="24"  height="24"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="w-16 w-16 2xl:hidden"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 6l16 0" /><path d="M4 12l16 0" /><path d="M4 18l16 0" /></svg>
            </button>

            <button v-show="props.mobileFloating" @click="uiStore.floatingNavigationOpen = false">
              <svg xmlns="http://www.w3.org/2000/svg"  width="24"  height="24"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="w-16 w-16"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M18 6l-12 12" /><path d="M6 6l12 12" /></svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss">
@keyframes appear {
  0% {
    transform:translateY(-200px);
  }

  100% {
    transform:translateY(0);
  }
}


@keyframes hideHeader {
  0% {
    transform:translateY(0px);
  }

  100% {
    transform:translateY(-200px);
  }
}


.appear {
  transform-origin:top;
  animation: appear .5s ease-out forwards;
}

.hide {
  transform-origin:top;
  animation: hideHeader .5s ease-out forwards;
}

</style>