<script setup lang="ts">
import {watch} from "vue"
import { Popover, PopoverButton, PopoverPanel } from '@headlessui/vue'
const popButton = ref<Element | null>();
const popPanel = ref<Element | null>();

const panelOpen = ref(false);

const popPanelState = reactive({
  mouseOver: false,
  created: false,
  closing: false,
})

const panelCreated = () => {
  popPanelState.closing = false;

  popPanel.value.addEventListener('mouseenter', () => {
    popPanelState.mouseOver = true
  })

  popPanel.value.addEventListener('mouseleave', () => {
    popPanelState.mouseOver = false

    setTimeout(() => {
      if(popPanelState.mouseOver) return;
      if(!panelOpen.value) return;
      if(popPanelState.closing) return;

      popButton.value.click();
      popPanelState.closing = true;
    }, 100)
  })
}

watch(() => popPanelState.created, () => {
  if(popPanelState.created && panelOpen.value) {
    panelCreated();
  }
});


const btnMouseEnter = (e, open) => {
  if(open) return;
  e.target.click();

  const observer = new MutationObserver((mutationsList) => {
    for (const mutation of mutationsList) {
      if (mutation.type === 'attributes' && mutation.attributeName === 'aria-controls') {
        let panelRefId = e.target.getAttribute('aria-controls');
        popPanel.value = document.getElementById(panelRefId);

       if(popPanel.value == null) return;
       if(popPanelState.created) return;

       popPanelState.created = true;

       let parent = popPanel.value?.parentElement;

        const deleteServer = new MutationObserver((mutationsList) => {
          for (const mutation of mutationsList) {
            if (mutation.type === 'childList') {
              if (![...parent.children].includes(popPanel.value)) {
                popPanelState.created = false;
                deleteServer.disconnect()
              }
            }
          }
        });

        deleteServer.observe(parent, {childList: true})
      }

      if(mutation.type === 'attributes' && mutation.attributeName === 'aria-expanded') {
        panelOpen.value = e.target.getAttribute('aria-expanded')
      }
    }
  });

  observer.observe(e.target, { attributes: true})
}
const btnMouseLeave = (e, open) => {
    popButton.value = e.target;

    if(!open || !popPanel) return;

    setTimeout(() => {
      if(popPanelState.mouseOver) return;
      if(popPanelState.closing) return;
      e.target.click();
      popPanelState.closing = true;
    }, 10)
}

</script>

<template>
  <Popover v-slot="{ open }" class="relative">
    <PopoverButton
        class="focus-visible:outline-none focus-visible:text-accent-ocean"
        @mouseenter.prevent="e => btnMouseEnter(e, open)"
        @mouseleave.prevent="e => btnMouseLeave(e, open)"
    >
       <slot
           name="button"
           :open="open"/>
    </PopoverButton>
    <transition
        enter-active-class="transition transform duration-150 ease-out"
        enter-from-class="scale-[60%] opacity-0"
        enter-to-class="scale-100 opacity-100"
        leave-active-class="transition transform duration-150 ease-in"
        leave-from-class="scale-100 opacity-100"
        leave-to-class="scale-[60%] opacity-0"
    >
      <PopoverPanel
          ref="popPanel"
          class="absolute left-1/2 z-10 mt-3 -translate-x-1/2 transform px-4 sm:px-0"
      >
        <slot
            name="panel"/>
      </PopoverPanel>
    </transition>
  </Popover>
</template>