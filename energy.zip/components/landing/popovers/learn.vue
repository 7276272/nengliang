<script setup lang="ts">

</script>


<template>
    <div class="w-screen lg:max-w-xs backdrop-blur-xl bg-bg1 min-h-[200px] h-full overflow-hidden rounded-[10%] shadow-xl ring-1 ring-black/5 border border-neutral-200 p-6">
      <span class="text-3xl text-black font-medium">Learn</span>

      <div class="flex flex-col justify-center items-center mt-8 gap-y-3">
        <div class="transition hover:bg-white cursor-pointer bg-white/50 py-6 px-4 rounded-2xl border border-neutral-200 flex flex-row items-center w-full">
          <span class="font-semibold text-lg basis-80">Blog</span>
        </div>

        <div class="transition hover:bg-white cursor-pointer bg-white/50 py-6 px-4 rounded-2xl border border-neutral-200 flex flex-row items-center w-full">
          <span class="font-semibold text-lg basis-80">FAQ</span>
        </div>

        <div class="transition hover:bg-white cursor-pointer bg-white/50 py-6 px-4 rounded-2xl border border-neutral-200 flex flex-row items-center w-full">
          <span class="font-semibold text-lg basis-80">Help Center</span>
        </div>
      </div>
    </div>
</template>

<style lang="scss">
.cls-1,.cls-2{fill-rule:evenodd;}.cls-1{fill:url(#linear-gradient);}.cls-2{fill:#fff;}
</style>