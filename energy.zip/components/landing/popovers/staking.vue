<script setup lang="ts">

</script>


<template>
    <div class="w-screen lg:max-w-xs backdrop-blur-xl bg-bg1 min-h-[200px] h-full overflow-hidden rounded-[10%] shadow-xl ring-1 ring-black/5 border border-neutral-200 p-6">
      <span class="text-3xl text-black font-medium">Staking</span>

      <div class="flex flex-col justify-center items-center mt-8 gap-y-3">
        <div class="transition hover:bg-white cursor-pointer bg-white/50 py-4 px-4 rounded-2xl border border-neutral-200 flex flex-row items-center w-full">
          <span class="font-semibold text-lg basis-80">Stake XAUT</span>
          <span class="p-1.5 rounded-full border border-neutral-150 flex items-center justify-center">
            <svg class="w-6 h-6" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 611.9 532.43"><defs><linearGradient id="linear-gradient" x1="4846.23" y1="-4671.46" x2="13324.84" y2="-4671.46" gradientTransform="matrix(0.07, 0, 0, -0.07, -348.93, -70.13)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#d8b35d"/><stop offset="1" stop-color="#f5e7bf"/></linearGradient></defs><title>tether-gold</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><g id="Layer_1-3" data-name="Layer_1"><path class="cls-1" d="M112.11,2.71.49,237.12a4.36,4.36,0,0,0,.9,5.23L302.7,531.22a4.72,4.72,0,0,0,6.32,0L610.51,242.35a4.41,4.41,0,0,0,.9-5.23L499.79,2.71a4.12,4.12,0,0,0-4-2.71H116.07a4.49,4.49,0,0,0-4,2.71Z"/><path class="cls-2" d="M344.72,261.1h0c-2.16.18-13.34.9-38.23.9-19.83,0-33.9-.54-38.95-.9h0c-76.63-3.42-133.79-16.77-133.79-32.64s57.16-29.39,133.79-32.81v52.11c5,.36,19.3,1.26,39.13,1.26,23.8,0,35.7-1.08,37.87-1.26V195.65c76.45,3.42,133.61,16.77,133.61,32.63s-57,29.4-133.43,32.82Zm0-70.68V143.71H451.47V72.49H160.8v71.22H267.54v46.71c-86.73,4-152,21.09-152,41.83s65.27,37.69,152,41.83V423.57h77.18V274.08c86.55-4,151.65-21.1,151.65-41.65s-65.1-38.05-151.65-42h0Z"/></g></g></g></svg>
          </span>
        </div>

        <div class="transition hover:bg-white cursor-pointer bg-white/50 py-4 px-4 rounded-2xl border border-neutral-200 flex flex-row items-center w-full">
          <span class="font-semibold text-lg basis-80">Stake USDT</span>
          <span class="p-1.5 rounded-full border border-neutral-150 flex items-center justify-center">
            <svg class="w-6 h-6" xmlns="http://www.w3.org/2000/svg" id="Layer_1" data-name="Layer 1" viewBox="0 0 339.43 295.27"><title>tether-usdt-logo</title><path d="M62.15,1.45l-61.89,130a2.52,2.52,0,0,0,.54,2.94L167.95,294.56a2.55,2.55,0,0,0,3.53,0L338.63,134.4a2.52,2.52,0,0,0,.54-2.94l-61.89-130A2.5,2.5,0,0,0,275,0H64.45a2.5,2.5,0,0,0-2.3,1.45h0Z" style="fill:#50af95;fill-rule:evenodd"/><path d="M191.19,144.8v0c-1.2.09-7.4,0.46-21.23,0.46-11,0-18.81-.33-21.55-0.46v0c-42.51-1.87-74.24-9.27-74.24-18.13s31.73-16.25,74.24-18.15v28.91c2.78,0.2,10.74.67,21.74,0.67,13.2,0,19.81-.55,21-0.66v-28.9c42.42,1.89,74.08,9.29,74.08,18.13s-31.65,16.24-74.08,18.12h0Zm0-39.25V79.68h59.2V40.23H89.21V79.68H148.4v25.86c-48.11,2.21-84.29,11.74-84.29,23.16s36.18,20.94,84.29,23.16v82.9h42.78V151.83c48-2.21,84.12-11.73,84.12-23.14s-36.09-20.93-84.12-23.15h0Zm0,0h0Z" style="fill:#fff;fill-rule:evenodd"/></svg>
          </span>
        </div>

        <div class="transition hover:bg-white cursor-pointer bg-white/50 py-4 px-4 rounded-2xl border border-neutral-200 flex flex-row items-center w-full">
        <span class="font-semibold text-lg basis-80">Stake EURT</span>
        <span class="p-1.5 rounded-full border border-neutral-150 flex items-center justify-center">
            <svg class="w-6 h-6" xmlns="http://www.w3.org/2000/svg" id="Layer_1" data-name="Layer 1" viewBox="0 0 339.43 295.27"><title>tether-usdt-logo</title><path d="M62.15,1.45l-61.89,130a2.52,2.52,0,0,0,.54,2.94L167.95,294.56a2.55,2.55,0,0,0,3.53,0L338.63,134.4a2.52,2.52,0,0,0,.54-2.94l-61.89-130A2.5,2.5,0,0,0,275,0H64.45a2.5,2.5,0,0,0-2.3,1.45h0Z" style="fill:#50af95;fill-rule:evenodd"/><path d="M191.19,144.8v0c-1.2.09-7.4,0.46-21.23,0.46-11,0-18.81-.33-21.55-0.46v0c-42.51-1.87-74.24-9.27-74.24-18.13s31.73-16.25,74.24-18.15v28.91c2.78,0.2,10.74.67,21.74,0.67,13.2,0,19.81-.55,21-0.66v-28.9c42.42,1.89,74.08,9.29,74.08,18.13s-31.65,16.24-74.08,18.12h0Zm0-39.25V79.68h59.2V40.23H89.21V79.68H148.4v25.86c-48.11,2.21-84.29,11.74-84.29,23.16s36.18,20.94,84.29,23.16v82.9h42.78V151.83c48-2.21,84.12-11.73,84.12-23.14s-36.09-20.93-84.12-23.15h0Zm0,0h0Z" style="fill:#fff;fill-rule:evenodd"/></svg>
          </span>
      </div>
      </div>
    </div>
</template>

<style lang="scss">
.cls-1,.cls-2{fill-rule:evenodd;}.cls-1{fill:url(#linear-gradient);}.cls-2{fill:#fff;}
</style>