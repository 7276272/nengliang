<template>
  <div id="why-us" class="after:absolute after:left-0 after:bottom-0 after:w-full after:h-[1px] after:bg-section-splitter relative w-full flex justify-center">
    <div class="px-20 2xl:max-w-screen-2xl justify-self-center w-full flex flex-col lg:flex-row">
      <div class="lg:basis-[28.9%] flex flex-col py-36">
        <div class="absolute -top-[200px] -left-[500px] bg-splash4 w-[1400px] h-[1400px] rounded-full"></div>
        <div class="sticky top-8 flex flex-col">
          <span class="text-[5rem] font-medium leading-[1]">WHY NAME?</span>
          <span class="mt-10 text-[2rem]">
            NAME is an autonomous system allowing users to provide and rent energy on Tron.
          </span>
        </div>
      </div>

      <div class="lg:flex hidden basis-[20%] items-center justify-center">
        <div class="relative py-36 w-[1px] h-full bg-section-splitter">
          <div class="sticky top-24 -ml-[55px] bg-bg1/60 z-10 flex justify-center items-center rounded-full border border-section-splitter w-[110px] h-[110px]">
            <svg  xmlns="http://www.w3.org/2000/svg"  width="50px"  viewBox="0 0 24 24"  fill="currentColor"  class="icon icon-tabler icons-tabler-filled icon-tabler-bolt"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M13 2l.018 .001l.016 .001l.083 .005l.011 .002h.011l.038 .009l.052 .008l.016 .006l.011 .001l.029 .011l.052 .014l.019 .009l.015 .004l.028 .014l.04 .017l.021 .012l.022 .01l.023 .015l.031 .017l.034 .024l.018 .011l.013 .012l.024 .017l.038 .034l.022 .017l.008 .01l.014 .012l.036 .041l.026 .027l.006 .009c.12 .147 .196 .322 .218 .513l.001 .012l.002 .041l.004 .064v6h5a1 1 0 0 1 .868 1.497l-.06 .091l-8 11c-.568 .783 -1.808 .38 -1.808 -.588v-6h-5a1 1 0 0 1 -.868 -1.497l.06 -.091l8 -11l.01 -.013l.018 -.024l.033 -.038l.018 -.022l.009 -.008l.013 -.014l.04 -.036l.028 -.026l.008 -.006a1 1 0 0 1 .402 -.199l.011 -.001l.027 -.005l.074 -.013l.011 -.001l.041 -.002z" /></svg>

          </div>
        </div>
      </div>

      <div class="lg:basis-[40%] flex justify-center flex-col lg:items-center lg:space-y-24 lg:py-36">
        <div class="absolute bottom-0 right-[0px]  bg-splash5 w-[1400px] h-[1400px] rounded-full"></div>
        <div class="flex flex-col">
          <span class="text-[4.2rem] leading-none">Secure and battle tested</span>
          <span class="mt-8 text-[1.3rem] text-neutral-500">$1,733,047,626 rewards paid since 2020.</span>
        </div>

        <div class="flex flex-col py-24">
          <span class="text-[4.2rem] leading-none">Competitive rewards and fees</span>
          <span class="mt-8 text-[1.3rem] text-neutral-500">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</span>
        </div>

        <div class="flex flex-col py-24">
          <span class="text-[4.2rem] leading-none">Fast & Seamless Transaction</span>
          <span class="mt-8 text-[1.3rem] text-neutral-500">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</span>

          <div class="mt-4 flex flex-row items-center">
            <div class="bg-bg1/60 z-10 flex justify-center items-center rounded-full border border-section-splitter w-[80px] h-[80px]">
              <img lazy src="@/assets/images/1inch.svg" class="w-[50px] h-[50px]"/>
            </div>

            <div class="-ml-5 bg-bg1/60 z-10 flex justify-center items-center rounded-full border border-section-splitter w-[80px] h-[80px]">
              <img lazy src="@/assets/images/curve.svg" class="w-[50px] h-[50px]"/>
            </div>

            <div class="-ml-5 bg-bg1/60 z-10 flex justify-center items-center rounded-full border border-section-splitter w-[80px] h-[80px]">
              <img lazy src="@/assets/images/balancer.svg" class="w-[50px] h-[50px]"/>
            </div>
          </div>
        </div>
      </div>


    </div>
</div>
</template>
<script setup lang="ts">
</script>