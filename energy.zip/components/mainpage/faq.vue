<script setup>
import Panel from "~/components/mainpage/panel.vue";

const faq = reactive([
  {
    q: "What is the use of TRX (TRON) energy?",
    a: `Currently, the scenario that uses the most energy on TRON is USDT transfer. Currently, when a transfer is made and the other party has a USDT balance, it requires 65k (13.2 TRX is burned if the energy is insufficient) energy. If the other party does not have a USDT balance, 131k (if insufficient energy needs to be burned, 27.3 TRX) energy is required. If there are insufficient resources, it will prompt “Insufficient Energy” and the transaction cannot be completed.`,
    open: false,
  },

  {
    q: "Why use TRX energy?",
    a: `Let’s take the transfer of TRC20 USDT as an example. When the other party has a USDT balance, 13TRX needs to be burned. After purchasing energy, only 3.50TRX is needed. Compared with burning TRX directly, it saves about 73% in handling fees. When the other party has no USDT balance, 27TRX needs to be burned. After purchasing energy, you only need 6.55TRX, Compared with burning TRX directly, it saves about 76% in handling fees. When you have stable wave field energy needs, contact customer service to get more discounts`,
    open: false,
  },

  {
    q: "I have enough TRX energy, still failed",
    a: `In addition to energy, transfers also require bandwidth. If it is just insufficient energy, the transaction will still try to proceed, but energy will be consumed, and finally it will prompt that TRX energy is insufficient. If the energy is sufficient but there is no bandwidth, transactions cannot be carried out. Generally, the wallet will prompt that TRX is insufficient. If it is called through API, the transaction will be initiated on the chain, but it will fail later and the block browser cannot query the transaction.`,
    open: false,
  },
])
</script>

<template>
  <div class="flex flex-col w-full">
    <div class="inline-flex items-center justify-between">
      <span class="text-[18px] font-bold">FAQ</span>
    </div>

    <div class="mt-4 flex flex-col transition gap-y-3">
        <panel v-for="q in faq" :key="q.q"
               @click="q.open = !q.open"
               :class="q.open ? 'max-h-[500px]' : 'max-h-[70px]'"
               class="transition-all duration-500 flex flex-col cursor-pointer overflow-hidden">
          <div class="flex flex-row items-center justify-between">
            <span class="text-lg font-bold text-white">{{q.q}}</span>
            <svg v-if="!q.open" xmlns="http://www.w3.org/2000/svg"  width="24"  height="24"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="icon icon-tabler icons-tabler-outline icon-tabler-chevron-down"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M6 9l6 6l6 -6" /></svg>
            <svg v-else xmlns="http://www.w3.org/2000/svg"  width="24"  height="24"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="icon icon-tabler icons-tabler-outline icon-tabler-chevron-up"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M6 15l6 -6l6 6" /></svg>
          </div>

          <div class="mt-10">
            <span class="text-sm text-textSecondary">{{q.a}}</span>
          </div>
        </panel>
    </div>
  </div>
</template>