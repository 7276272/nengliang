<script setup>
const ui = useMainPageUIStore();
</script>

<template>
  <div class="inline-flex md:hidden fixed bottom-0 left-0 w-full bg-bgPanel min-h-[60px] justify-center items-center z-[999]">
    <div v-for="route in ui.routes" :key="route.pathName"
        @click="navigateTo(route.pathName)"
        class="mx-8 flex flex-col justify-center items-center gap-y-1 cursor-pointer hover:text-white"
    >
        <span :class="{'text-accent-cyan':  ui.currentRoute === route.pathName}" v-html="route.svg"/>
        <span
            :class="{'text-white':  ui.currentRoute === route.pathName}"
            class="text-sm">{{route.name}}</span>
    </div>
  </div>
</template>