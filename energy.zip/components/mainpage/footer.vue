<template>
  <footer class="flex justify-center items-center w-full">
    <div class="max-w-[1440px] before:w-full before:h-[1px] before:bg-white/[12%] before:absolute before:top-0 before:left-0 relative flex flex-row w-full py-6">
      <div class="basis-full text-white">
        <span class="text-3xl tracking-widest font-bold basis-[10%]">LOGO</span>
      </div>

      <div class="basis-[20%] flex flex-row items-center divide-x divide-white/[12%]">
        <span class="text-sm font-medium text-textSecondary hover:text-accent-cyan cursor-pointer hover:opacity-80 px-3">Terms Of Use</span>
        <span class="text-sm font-medium text-textSecondary hover:text-accent-cyan cursor-pointer hover:opacity-80 px-3">Privacy Notice</span>
      </div>
    </div>
  </footer>
</template>
<script setup lang="ts">
</script>