<script setup>
import FloatingNavigation from "~/components/mainpage/floatingNavigation.vue";
import AddyBtn from "~/components/core/addyBtn.vue";

const ui = useMainPageUIStore();
const walletStore = useMainPageWallet();
const { loggedIn, clear } = useUserSession()

import {useAuthStore} from "~/stores/auth-store.ts"
const authStore = useAuthStore()

</script>

<template>
  <div class="min-h-[82px] w-full flex items-center">
    <div class="flex justify-center px-10 w-full items-center">
      <div
          class="2xl:max-w-screen-xl w-full py-8">
        <div class="flex flex-row items-center  flex-wrap sm:flex-nowrap">

          <NuxtLink
              to="/" class="text-3xl tracking-widest font-bold basis-full md:basis-[20%]">LOGO</NuxtLink>
          <div class="md:inline-flex hidden basis-full xl:basis-[70%]">
            <span v-for="route_ in ui.routes" :key="route_.pathName"
                  @click="ui.navigate(route_.pathName)"
                  class="select-none cursor-pointer hover:text-white inline-flex items-center mx-5">
              <span
                  :class="{'text-accent-cyan':  ui.currentRoute === route_.pathName}"
                  v-html="route_.svg"></span>
              <span
                  :class="{'text-white':  ui.currentRoute === route_.pathName}"
                  class="ms-2 text-xs font-medium">{{route_.name}}</span>
            </span>
          </div>

          <div class="justify-self-end justify-end flex flex-row items-center">
            <NuxtLink v-if="!loggedIn" as="button" to="/auth/login" class="me-6 text-md font-medium">Login</NuxtLink>

            <NuxtLink v-if="!loggedIn" as="button" to="/auth/register"
                class="text-center text-shadow text-sm bg-accent-cyan rounded-lg text-white font-bold w-[120px] px-2 py-2 transition-colors hover:bg-accent-ocean">
              Register
            </NuxtLink>

            <NuxtLink v-if="loggedIn" to="/auth/register"
                      class="me-6 text-center text-shadow text-sm bg-accent-cyan rounded-lg text-white font-bold w-[160px] px-2 py-2 transition-colors hover:bg-accent-ocean">
              Connect Wallet
            </NuxtLink>

            <button v-if="loggedIn"
                    @click="clear()"
                    class="me-6 text-lg font-medium inline-flex items-center">
              <svg  xmlns="http://www.w3.org/2000/svg"  width="24"  height="24"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="icon icon-tabler icons-tabler-outline icon-tabler-logout"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M14 8v-2a2 2 0 0 0 -2 -2h-7a2 2 0 0 0 -2 2v12a2 2 0 0 0 2 2h7a2 2 0 0 0 2 -2v-2" /><path d="M9 12h12l-3 -3" /><path d="M18 15l3 -3" /></svg>
              <span class="ms-1.5">Logout</span>
            </button>



          </div>


        </div>
      </div>
    </div>
  </div>
  <floating-navigation/>
</template>