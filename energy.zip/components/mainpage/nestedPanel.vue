<template>
  <div class="w-full bg-bgPanelPanel py-3 px-4 rounded-xl">
    <slot/>
  </div>
</template>