<template>
  <div class="w-full h-full bg-bgPanel rounded-2xl py-6 px-8 shadow-lg z-10">
    <slot/>
  </div>
</template>