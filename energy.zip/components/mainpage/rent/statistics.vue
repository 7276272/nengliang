<script setup lang="ts">
import Panel from "~/components/mainpage/panel.vue";
</script>

<template>
<div class="flex flex-col w-full">
  <div class="inline-flex items-center justify-between">
    <span class="text-[18px] font-bold">Statistics</span>
  </div>

  <panel class="mt-4">
    <div class="flex flex-col gap-y-4">
      <div class="flex flex-row justify-between items-center">
        <span class="text-[12px] text-textSecondary/80">Total energy rented</span>
        <span class="text-sm text-white">9,836,248.731</span>
      </div>

      <div class="flex flex-row justify-between items-center">
        <span class="text-[12px] text-textSecondary/80">Total users served</span>
        <span class="text-sm text-white">98,521</span>
      </div>

    </div>
  </panel>
</div>
</template>
