<script setup lang="ts">
import Addy from "~/components/core/addy.vue";
const walletStore = useMainPageWallet();
</script>

<template>
  <div class="w-full rounded-3xl py-8 px-8 z-1 flex flex-col bg-bgPanel">
    <div class="flex flex-row items-center w-full">
      <div class="basis-[30%] flex flex-col leading-relaxed">
        <span class="text-[12px] font-thin tracking-wider text-textSecondary">DAI rewarded</span>
        <span class="text-[16px] font-normal text-green-400 tracking-wide my-2">- stETH</span>
        <span class="text-xs text-textSecondary">$ -</span>
      </div>

      <div class="basis-[30%] flex flex-col leading-relaxed">
        <span class="text-[12px] font-thin tracking-wider text-textSecondary">Average APR</span>
        <span class="text-[16px] font-medium tracking-wide my-2">- %</span>
        <span class="text-xs text-blue-400 cursor-pointer hover:opacity-80">More info</span>
      </div>

      <div class="basis-[30%] flex flex-col leading-relaxed">
        <span class="text-[12px] font-thin tracking-wider text-textSecondary">DAI price</span>
        <span class="text-[16px] font-medium tracking-wide my-2">- %</span>
        <span class="text-xs text-blue-400 cursor-pointer hover:opacity-80">- DAI</span>
      </div>
    </div>
    </div>
</template>