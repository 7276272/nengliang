<script setup lang="ts">
import Addy from "~/components/core/addy.vue";
const walletStore = useMainPageWallet();

const props = defineProps({
  balanceOnly: Boolean
})
</script>

<template>
  <div class="w-full rounded-tl-2xl rounded-tr-2xl py-8 px-8 translate-y-4 z-1 flex flex-col bg-walletOverviewBG ">
    <div class="flex flex-row items-center justify-between">
      <div class="flex flex-col leading-relaxed">
        <span class="text-sm">DAI balance</span>
        <span class="text-[16px] font-extrabold tracking-wide">0.0 DAI</span>
      </div>

      <div>
        <addy
            :avatar="walletStore.wallet.avatar"
            :address="walletStore.wallet.address"/>
      </div>
    </div>

    <span  v-if="props.balanceOnly" class="mt-2 text-sm tracking-[.3em] text-neutral-200">
      $0
    </span>
    <div v-if="!props.balanceOnly" class="w-full before:absolute relative before:h-[1px] before:w-full before:bg-white/[10%] py-5"></div>

    <div  v-if="!props.balanceOnly" class="flex items-center flex-wrap gap-y-4">
      <div class="basis-[55%] flex flex-col">
        <span class="text-sm">My requests</span>

        <div class="inline-flex items-center divide-x divide-white/30 mt-2">
          <div class="pr-3 inline-flex items-center">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><path fill-rule="evenodd" clip-rule="evenodd" d="M5.113 1.333h5.78c2.26 0 3.774 1.587 3.774 3.947v5.447c0 2.353-1.514 3.94-3.774 3.94h-5.78c-2.26 0-3.78-1.587-3.78-3.94V5.28c0-2.36 1.52-3.947 3.78-3.947zm2.507 8.66l3.167-3.166a.587.587 0 000-.827.587.587 0 00-.827 0L7.207 8.754 6.04 7.587a.587.587 0 00-.827 0 .587.587 0 000 .827L6.8 9.994a.57.57 0 00.407.166.57.57 0 00.413-.167z" fill="#53BA95"></path></svg>
            <span class="ms-2 text-[16px] font-extrabold">0</span>
          </div>

          <div class="pl-3 inline-flex items-center">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><path fill-rule="evenodd" clip-rule="evenodd" d="M5.113 1.333h5.78c2.26 0 3.774 1.587 3.774 3.946v5.447c0 2.354-1.514 3.94-3.774 3.94h-5.78c-2.26 0-3.78-1.586-3.78-3.94V5.28c0-2.36 1.52-3.946 3.78-3.946zm5.274 9.207a.495.495 0 00.426-.246.496.496 0 00-.173-.687L8.267 8.194V5.113a.5.5 0 10-1 0V8.48c0 .173.093.34.246.427l2.614 1.56a.47.47 0 00.26.073z" fill="#EC8600"></path></svg>
            <span class="ms-2 text-[16px] font-extrabold">0</span>
          </div>
        </div>
      </div>

      <div class="flex flex-col">
        <span class="text-sm">Withdrawals mode</span>

        <div class="inline-flex items-center mt-2">
          <div class="onlineDot"></div>
          <span class="font-extrabold text-[16px]">Turbo</span>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
@keyframes eFjETa {
  0% {
    transform: scale(0.95);
    box-shadow: rgba(83, 186, 149, 0.7) 0px 0px 0px 0px;
  }

  70% {
    transform: scale(1);
    box-shadow: rgba(83, 186, 149, 0) 0px 0px 0px 6px;
  }

  100% {
    transform: scale(0.95);
    box-shadow: rgba(83, 186, 149, 0) 0px 0px 0px 0px;
  }
}


.onlineDot {
  border-radius: 50%;
  margin-right: 8px;
  height: 8px;
  width: 8px;
  transform: scale(1);
  background: #53BA95;
  box-shadow: 0 0 0 0 #53BA95;
  animation-name: eFjETa;
  animation-duration: 2s;
  animation-iteration-count: infinite;
}
</style>