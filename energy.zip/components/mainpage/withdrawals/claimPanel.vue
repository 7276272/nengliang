<script setup lang="ts">
import Panel from "~/components/mainpage/panel.vue";
import Input from "~/components/core/input.vue";
import NestedPanel from "~/components/mainpage/nestedPanel.vue";

const walletStore = useMainPageWallet();
</script>

<template>
  <panel>
    <div class="w-full h-full flex items-center justify-center py-20">
      <span class="text-sm text-white/70">No withdrawal requests detected.</span>
    </div>

    <button
        v-if="walletStore.connected"
        class="mt-6 text-shadow text-sm bg-accent-cyan rounded-lg text-white font-bold px-7 w-full py-3.5 transition-colors hover:bg-accent-ocean">
      Connect Wallet
    </button>

    <button
        v-else
        class="mt-6 text-shadow text-sm bg-accent-cyan rounded-lg text-white font-bold px-7 w-full py-3.5 transition-colors hover:bg-accent-ocean">
      Claim
    </button>

    <div class="mt-4 flex flex-row justify-between items-center">
      <span class="text-[12px] text-textSecondary/80">Max transaction cost</span>
      <span class="text-sm text-white">$10.88</span>
    </div>
  </panel>
</template>
