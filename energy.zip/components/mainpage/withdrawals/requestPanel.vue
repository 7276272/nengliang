<script setup lang="ts">
import Panel from "~/components/mainpage/panel.vue";
import Input from "~/components/core/input.vue";
import NestedPanel from "~/components/mainpage/nestedPanel.vue";

const walletStore = useMainPageWallet();
</script>

<template>
  <panel>
    <form class="mb-6">
      <Input
          placeholder="DAI amount"
      >
        <template #icon>
          <img src="@/assets/images/dai.svg"/>
        </template>
      </Input>

      <nested-panel class="mt-4">
        <div class="inline-flex items-center justify-between py-2 w-full">
          <div class="inline-flex items-center">
            <img class="w-10" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDUiIGhlaWdodD0iNDQiIHZpZXdCb3g9IjAgMCA0NSA0NCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTIyLjAwMSA0NC4wMDFDMzQuMTUxOCA0NC4wMDEgNDQuMDAyIDM0LjE1MDggNDQuMDAyIDIyQzQ0LjAwMiA5Ljg0OTIxIDM0LjE1MTggLTAuMDAwOTc2NTYyIDIyLjAwMSAtMC4wMDA5NzY1NjJDOS44NTAxOSAtMC4wMDA5NzY1NjIgMCA5Ljg0OTIxIDAgMjJDMCAzNC4xNTA4IDkuODUwMTkgNDQuMDAxIDIyLjAwMSA0NC4wMDFaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMjIgMjQuOTg1OUwxNC41MDcxIDIwLjcwNTlMMTQuMzAyNSAyMS4wMTk4QzExLjk5NDcgMjQuNTYgMTIuNTEwMSAyOS4xOTYzIDE1LjU0MTcgMzIuMTY2N0MxOS4xMDkgMzUuNjYyMSAyNC44OTI5IDM1LjY2MjEgMjguNDYwMiAzMi4xNjY3QzMxLjQ5MTggMjkuMTk2MyAzMi4wMDcyIDI0LjU2IDI5LjY5OTQgMjEuMDE5OEwyOS40OTQ3IDIwLjcwNThMMjIgMjQuOTg1OVoiIGZpbGw9InVybCgjcGFpbnQwX3JhZGlhbF8xMjkzXzI3NDcyKSIvPgo8cGF0aCBvcGFjaXR5PSIwLjYiIGQ9Ik0yMi4wMDk3IDE1LjQyNzVMMTUuNTUwOCAxOS4xMjA3TDIyLjAwOTcgMjIuODA5M0wyOC40NjQgMTkuMTIwOEwyMi4wMDk3IDE1LjQyNzVaIiBmaWxsPSJ1cmwoI3BhaW50MV9yYWRpYWxfMTI5M18yNzQ3MikiLz4KPHBhdGggZD0iTTIyLjAxNzUgMTYuMzkxOEwxNC41MTIyIDIwLjcxMDRMMjIuMDAwNyAyNC45OTIzTDI5LjQ5NjMgMjAuNzA5TDIyLjAxNzUgMTYuMzkxOFoiIGZpbGw9InVybCgjcGFpbnQyX2RpYW1vbmRfMTI5M18yNzQ3MikiLz4KPHBhdGggZD0iTTIyLjAwOTcgOS4yMTUzM0wxNS41NTA4IDE5LjExOUwyMi4wMDk3IDIyLjgwNzVWOS4yMTUzM1oiIGZpbGw9InVybCgjcGFpbnQzX2xpbmVhcl8xMjkzXzI3NDcyKSIvPgo8cGF0aCBkPSJNMjIuMDA4MyAyMi44MDk2TDI4LjQ2NzggMTkuMTIwNUwyMi4wMDg3IDkuMjExOTFMMjIuMDA4MyAyMi44MDk2WiIgZmlsbD0idXJsKCNwYWludDRfbGluZWFyXzEyOTNfMjc0NzIpIi8+CjxkZWZzPgo8cmFkaWFsR3JhZGllbnQgaWQ9InBhaW50MF9yYWRpYWxfMTI5M18yNzQ3MiIgY3g9IjAiIGN5PSIwIiByPSIxIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgZ3JhZGllbnRUcmFuc2Zvcm09InRyYW5zbGF0ZSgyMS45OTI4IDM0Ljc5NDcpIHJvdGF0ZSgtOTApIHNjYWxlKDEyLjE1ODggMTUuODkwOSkiPgo8c3RvcCBvZmZzZXQ9IjAuMjAzNjk1IiBzdG9wLWNvbG9yPSIjNTZGMkZGIi8+CjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzRBOENFQSIvPgo8L3JhZGlhbEdyYWRpZW50Pgo8cmFkaWFsR3JhZGllbnQgaWQ9InBhaW50MV9yYWRpYWxfMTI5M18yNzQ3MiIgY3g9IjAiIGN5PSIwIiByPSIxIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgZ3JhZGllbnRUcmFuc2Zvcm09InRyYW5zbGF0ZSgyMi4wMDc0IDE5LjExODQpIHJvdGF0ZSg5MC4xNjA3KSBzY2FsZSgzLjY4MDkxIDYuOTY4OCkiPgo8c3RvcCBzdG9wLWNvbG9yPSIjRUVGRjgzIi8+CjxzdG9wIG9mZnNldD0iMC42ODk1OTYiIHN0b3AtY29sb3I9IiM1Njk5RUMiLz4KPC9yYWRpYWxHcmFkaWVudD4KPHJhZGlhbEdyYWRpZW50IGlkPSJwYWludDJfZGlhbW9uZF8xMjkzXzI3NDcyIiBjeD0iMCIgY3k9IjAiIHI9IjEiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIiBncmFkaWVudFRyYW5zZm9ybT0idHJhbnNsYXRlKDIyLjAwNDIgMjAuNjkyMSkgcm90YXRlKDkwLjE2KSBzY2FsZSg0LjI4ODYgOC4wODYzNikiPgo8c3RvcCBzdG9wLWNvbG9yPSIjNTZGMkZGIi8+CjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzU2OTlFQyIvPgo8L3JhZGlhbEdyYWRpZW50Pgo8bGluZWFyR3JhZGllbnQgaWQ9InBhaW50M19saW5lYXJfMTI5M18yNzQ3MiIgeDE9IjE4Ljc4MDIiIHkxPSI5LjIxNTMzIiB4Mj0iMTguNzgwMiIgeTI9IjIyLjgwNzUiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj4KPHN0b3Agb2Zmc2V0PSIwLjM3NzE3OSIgc3RvcC1jb2xvcj0iI0ZGRTMzNiIvPgo8c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiMxM0MwQjYiIHN0b3Atb3BhY2l0eT0iMC43Ii8+CjwvbGluZWFyR3JhZGllbnQ+CjxsaW5lYXJHcmFkaWVudCBpZD0icGFpbnQ0X2xpbmVhcl8xMjkzXzI3NDcyIiB4MT0iMjUuMjM4MSIgeTE9IjkuMjExOTEiIHgyPSIyNS4yMzgxIiB5Mj0iMjIuODA5NiIgZ3JhZGllbnRVbml0cz0idXNlclNwYWNlT25Vc2UiPgo8c3RvcCBvZmZzZXQ9IjAuNDA4ODE3IiBzdG9wLWNvbG9yPSIjRkY3RjcyIi8+CjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzI5NzhFRiIgc3RvcC1vcGFjaXR5PSIwLjciLz4KPC9saW5lYXJHcmFkaWVudD4KPC9kZWZzPgo8L3N2Zz4K" alt="">
            <span class="ms-4 font-light">Lido</span>
          </div>

          <span class="font-bold text-white text-[14px]">
            0.0 DAI
          </span>
        </div>
      </nested-panel>

      <button
          v-if="walletStore.connected"
          class="mt-6 text-shadow text-sm bg-accent-cyan rounded-lg text-white font-bold px-7 w-full py-3.5 transition-colors hover:bg-accent-ocean">
        Connect Wallet
      </button>

      <button
          v-else
          class="mt-6 text-shadow text-sm bg-accent-cyan rounded-lg text-white font-bold px-7 w-full py-3.5 transition-colors hover:bg-accent-ocean">
        Request Withdrawal
      </button>

      <div class="mt-6 flex flex-col gap-y-4">
        <div class="flex flex-row justify-between items-center">
          <span class="text-[12px] text-textSecondary/80">Max unlock cost</span>
          <span class="text-sm text-white">FREE</span>
        </div>

        <div class="flex flex-row justify-between items-center">
          <span class="text-[12px] text-textSecondary/80">Max transaction cost</span>
          <span class="text-sm text-white">$4.19</span>
        </div>

        <div class="flex flex-row justify-between items-center">
          <span class="text-[12px] text-textSecondary/80">Allowance</span>
          <span class="text-sm text-white">0.0 DAI</span>
        </div>

        <div class="flex flex-row justify-between items-center">
          <span class="text-[12px] text-textSecondary/80">Exchange rate</span>
          <span class="text-sm text-white">1 DAI = 1 USDC</span>
        </div>
      </div>
    </form>
  </panel>
</template>
