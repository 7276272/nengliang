export const makeUUID = (length) => {
    return [...Array(length)].map(() => (Math.random() * 36 | 0).toString(36)).join('');
}