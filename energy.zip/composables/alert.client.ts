import {h, VNode} from "vue"
import {useMount} from "vue3-mount"
import Alert from "@/components/core/alert.vue"

const QUE_FULL = -1
type Type = "success" | "error" | "loading";

interface Options {
    type?: Type,
    expire?: Boolean,
    content: String,
}

const queue = reactive([]);
const MAX_QUEUE_SIZE = 5;
export const ALERT_QUEUE_SIZE = computed(() => queue.length);

(async () => {
    while(true) {
        if(queue.length > 0) {
                const alert = queue[0]
                await alert();
                queue.shift()
        } else {
            await new Promise(resolve => setTimeout(resolve, 200));
        }
    }
})()


export const useAlert = () =>{
    return async (opts : Options,  cb?: Function) => {
        return new Promise((reject) => {
            if (queue.length >= 5) {
                reject(QUE_FULL);
                return;
            }

            queue.push(() => {
                return new Promise((resolve) => {
                    const mount = useMount()
                    mount(() => h(Alert, {
                        type: opts.type,
                        expire: opts.expire,
                        content: opts.content,
                        close: () => {
                            resolve()
                            if(cb) cb()
                        }
                    }), "alerts")
                })
            })
        })
    }
}