<script setup>

</script>
<template>
  <div class="h-screen w-screen flex items-center justify-center fixed left-0 top-0 z-0 bg-bg2">
    <svg width="1560" height="784" style="opacity:80%" class="sc-df70e51c-0 jlDhik"><radialGradient id="background-gradient1" cx="50%" y="50%"><stop offset="0%" style="stop-color: #01A3FE"></stop><stop offset="100%" style="stop-color: #1C1C21"></stop></radialGradient><rect width="1560" height="784" opacity=".1" fill="url(#background-gradient1)"></rect></svg>
  </div>

  <div class="z-[9990] w-full flex items-center absolute">
    <div class="flex justify-center px-10 w-full">
      <div
          class="w-full py-3">
        <div class="flex flex-row items-center flex-wrap gap-y-4">
          <NuxtLink to="/rent" class="text-3xl tracking-widest font-bold basis-[10%] text-neutral-200">LOGO</NuxtLink>
        </div>
      </div>
    </div>
  </div>

  <div class="flex flex-col w-full h-screen text-white/80 z-[10] relative items-center justify-center">
  <div class="my-5 w-full flex items-center justify-center text-white">
    <div class="max-w-[500px] flex flex-col items-center justify-center w-full px-4">
      <slot/>
    </div>
  </div>
  </div>
</template>

<style lang="scss">

</style>