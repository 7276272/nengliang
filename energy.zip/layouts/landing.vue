<script setup>
import Header from "~/components/landing/header.vue";
import FloatingNavigation from "~/components/landing/floatingNavigation.vue";
import Footer from "~/components/landing/footer.vue";
import FooterCopyrights from "~/components/landing/footerCopyrights.vue";
const uiStore = useLandingUIStore();

useHead({
  bodyAttrs: {
    class: () => uiStore.floatingNavigationOpen ? 'overflow-hidden' : ''
  }
})
</script>

<template>
  <transition
    mode="in-out"
    enter-active-class="transition"
    leave-active-class="transition"
    enter-from-class="opacity-0"
    enter-to-class="opacity-100"
    leave-from-class="opacity-100"
    leave-to-class="opacity-0"
  >
    <floating-navigation v-if="uiStore.floatingNavigationOpen"/>
  </transition>
  <div class="w-full grid">
    <Header :mobile-floating="uiStore.floatingNavigationOpen"/>
    <slot/>
    <Footer/>
    <FooterCopyrights/>
  </div>
</template>

