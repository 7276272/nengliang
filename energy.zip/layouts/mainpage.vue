<script setup lang="ts">
import Header from "~/components/mainpage/header.vue";
import Footer from "~/components/mainpage/footer.vue";
</script>

<template>
  <div class="h-screen w-screen flex items-center justify-center fixed left-0 top-0 z-0 bg-bg2">
    <svg width="1560" height="784" style="opacity:80%" class="sc-df70e51c-0 jlDhik"><radialGradient id="background-gradient" cx="50%" y="50%"><stop offset="0%" style="stop-color: #01A3FE"></stop><stop offset="100%" style="stop-color: #1C1C21"></stop></radialGradient><rect width="1560" height="784" opacity=".1" fill="url(#background-gradient)"></rect></svg>
  </div>

  <div class="flex flex-col w-full h-screen text-white/80 z-[10] relative">
    <Header/>
    <div class="basis-full">
      <slot/>
    </div>
    <Footer class="mt-12"/>
  </div>
</template>
