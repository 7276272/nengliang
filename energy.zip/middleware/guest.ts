export default defineNuxtRouteMiddleware((to, from) => {
    console.log('From guest middleware')
})