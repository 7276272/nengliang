<script setup>
definePageMeta({
  middleware: ['guest'],
  pageTransition: {
    name: "jump",
    mode: "out-in",
    duration: 250
  }
})
</script>

<template>
  <NuxtPage/>
</template>

<style lang="scss">
.asd {

}
</style>