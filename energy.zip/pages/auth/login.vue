<script setup>
definePageMeta({
  layout: "auth"
})

import panel from "~/components/mainpage/panel.vue";
import Input from "~/components/core/input.vue";
import {useAuthStore} from "~/stores/auth-store.ts"
const authStore = useAuthStore()

import {Field, Form, useField, ErrorMessage, configure} from "vee-validate";
import {localize} from "@vee-validate/i18n";

const state = reactive({
  email: null,
  password: null,
})

const formSchema = {
  email: 'required|email',
  password: 'required|min:6|max:24',
}

const onSubmit = (formValues) => {
  authStore.makeAuth(formValues)
}

configure({
  generateMessage: localize('en', {
    fields: {
      email: {
        required: "Please, enter your E-mail address.",
        email: "Please, enter your E-mail address.",
      },
      password: {
        required: "Please, enter your password.",
        min: "Please, enter your password.",
        max: "Please, enter your password.",
      },

    }
  })
});


</script>

<template>
  <div class="flex flex-col justify-center items-center w-full h-full">
    <span class="text-3xl font-bold">Login</span>
    <span class="text-md text-white/80 mt-1 tracking-wide mb-2">Log in your account to start renting energy.</span>

    <panel class="mt-4">
      <Form
          as="div"
          v-slot="{ errors, values, handleSubmit }"
          :validation-schema="formSchema"
      >
        <form
            @submit.prevent="handleSubmit($event, onSubmit)"
            class="flex flex-col">
        <div>
          <Input
              placeholder="E-Mail address"
              name="email"
              type="email"
          >
            <template #icon>
              <svg  xmlns="http://www.w3.org/2000/svg"  width="24"  height="24"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="ml-3 icon icon-tabler icons-tabler-outline icon-tabler-at"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 12m-4 0a4 4 0 1 0 8 0a4 4 0 1 0 -8 0" /><path d="M16 12v1.5a2.5 2.5 0 0 0 5 0v-1.5a9 9 0 1 0 -5.5 8.28" /></svg>
            </template>
          </Input>
          <ErrorMessage class="text-red-400 font-light text-sm" name="email"/>
        </div>

        <div class="my-3">
          <Input
              name="password"
              placeholder="Password"
              type="password"
          >
            <template #icon>
              <svg  xmlns="http://www.w3.org/2000/svg"  width="24"  height="24"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="ml-3 icon icon-tabler icons-tabler-outline icon-tabler-lock-square-rounded"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 3c7.2 0 9 1.8 9 9s-1.8 9 -9 9s-9 -1.8 -9 -9s1.8 -9 9 -9z" /><path d="M8 11m0 1a1 1 0 0 1 1 -1h6a1 1 0 0 1 1 1v3a1 1 0 0 1 -1 1h-6a1 1 0 0 1 -1 -1z" /><path d="M10 11v-2a2 2 0 1 1 4 0v2" /></svg>
            </template>
          </Input>
          <ErrorMessage class="text-red-400 font-light text-sm" name="password"/>
        </div>

        <button
            type="submit"
            class="mt-2 text-shadow text-sm bg-accent-cyan rounded-lg text-white font-bold px-7 w-full py-3.5 transition-colors hover:bg-accent-ocean">
          Log In
        </button>

        <div class="inline-flex w-full text-center mt-4 justify-center">
          <NuxtLink
              to="/auth/register"
              class="text-center text-sm text-neutral-400 hover:text-accent-cyan transition">Don't have an account yet?</NuxtLink>
        </div>
      </form>
      </Form>
    </panel>
  </div>
</template>