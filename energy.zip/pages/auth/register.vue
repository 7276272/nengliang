<script setup>
definePageMeta({
  layout: "auth"
})

import panel from "~/components/mainpage/panel.vue";
import Input from "~/components/core/input.vue";
import {useAuthStore} from "~/stores/auth-store.ts"
const authStore = useAuthStore()

const state = reactive({
  email: null,
  password: null,
})

import {Field, Form, useField, ErrorMessage, configure} from "vee-validate";
import {localize} from "@vee-validate/i18n";


const formSchema = {
  email: 'required|email',
  password: 'required|min:6|max:24',
  password_confirmed: 'required|confirmed:password',
}

const onSubmit = (formValues) => {
  authStore.makeRegister(formValues)
}

configure({
  generateMessage: localize('en', {
    fields: {
      email: {
        required: "Please, enter your E-mail address.",
        email: "Please, enter your E-mail address.",
      },
      password: {
        required: "Please, enter your password.",
        min: "Password must be at least 6 character length.",
        max: "Password can't be longer than 24 characters.",
      },

      password_confirmed: {
        required: "Please, enter your password again.",
        confirmed: "Passwords must match",
      }
    }
  })
});
</script>

<template>
  <div class="flex flex-col justify-center items-center w-full h-full">
  <span class="text-3xl font-bold">Register</span>
  <span class="text-sm max-w-[300px] text-white/80 mt-1 tracking-wide mb-2 text-center">Start renting energy and winning rewards, its completely free!</span>

    <panel class="mt-4">
      <Form
          as="div"
          v-slot="{ errors, values, handleSubmit }"
          :validation-schema="formSchema"
      >
        <form
            @submit.prevent="handleSubmit($event, onSubmit)"
            class="flex flex-col">
          <div class="my-1">
            <Input
                placeholder="E-Mail address"
                name="email"
                type="email"
            >
              <template #icon>
                <svg  xmlns="http://www.w3.org/2000/svg"  width="24"  height="24"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="ml-3 icon icon-tabler icons-tabler-outline icon-tabler-at"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 12m-4 0a4 4 0 1 0 8 0a4 4 0 1 0 -8 0" /><path d="M16 12v1.5a2.5 2.5 0 0 0 5 0v-1.5a9 9 0 1 0 -5.5 8.28" /></svg>
              </template>
            </Input>
            <ErrorMessage class="text-red-400 font-light text-sm" name="email"/>
          </div>

          <div class="my-1">
            <Input
                name="password"
                placeholder="Password"
                type="password"
            >
              <template #icon>
                <svg  xmlns="http://www.w3.org/2000/svg"  width="24"  height="24"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="ml-3 icon icon-tabler icons-tabler-outline icon-tabler-key"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M16.555 3.843l3.602 3.602a2.877 2.877 0 0 1 0 4.069l-2.643 2.643a2.877 2.877 0 0 1 -4.069 0l-.301 -.301l-6.558 6.558a2 2 0 0 1 -1.239 .578l-.175 .008h-1.172a1 1 0 0 1 -.993 -.883l-.007 -.117v-1.172a2 2 0 0 1 .467 -1.284l.119 -.13l.414 -.414h2v-2h2v-2l2.144 -2.144l-.301 -.301a2.877 2.877 0 0 1 0 -4.069l2.643 -2.643a2.877 2.877 0 0 1 4.069 0z" /><path d="M15 9h.01" /></svg>
              </template>
            </Input>
            <ErrorMessage class="text-red-400 font-light text-sm" name="password"/>
          </div>

          <div class="my-1">
            <Input
                name="password_confirmed"
                placeholder="Confirm Password"
                type="password"
            >
              <template #icon>
                <svg  xmlns="http://www.w3.org/2000/svg"  width="24"  height="24"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="ml-3 icon icon-tabler icons-tabler-outline icon-tabler-key"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M16.555 3.843l3.602 3.602a2.877 2.877 0 0 1 0 4.069l-2.643 2.643a2.877 2.877 0 0 1 -4.069 0l-.301 -.301l-6.558 6.558a2 2 0 0 1 -1.239 .578l-.175 .008h-1.172a1 1 0 0 1 -.993 -.883l-.007 -.117v-1.172a2 2 0 0 1 .467 -1.284l.119 -.13l.414 -.414h2v-2h2v-2l2.144 -2.144l-.301 -.301a2.877 2.877 0 0 1 0 -4.069l2.643 -2.643a2.877 2.877 0 0 1 4.069 0z" /><path d="M15 9h.01" /></svg>
              </template>
            </Input>
            <ErrorMessage class="text-red-400 font-light text-sm" name="password_confirmed"/>
          </div>

          <button
              type="submit"
              class="mt-4 text-shadow text-sm bg-accent-cyan rounded-lg text-white font-bold px-7 w-full py-3.5 transition-colors hover:bg-accent-ocean">
            Register
          </button>

          <div class="inline-flex w-full text-center mt-4 justify-center">
            <NuxtLink
            to="/auth/login"
            class="text-center text-sm text-neutral-400 hover:text-accent-cyan transition">Already have an account?</NuxtLink>
      </div>
    </form>
      </Form>
  </panel>
  </div>
</template>