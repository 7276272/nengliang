<script setup lang="ts">
import Landing from "~/layouts/landing.vue";
import Heading from "~/components/landing/heading.vue";
import Features from "~/components/landing/features.vue";
import RewardCoin from "~/components/landing/rewardCoin.vue";
import Footer from "~/components/landing/footer.vue";
import FooterCopyrights from "~/components/landing/footerCopyrights.vue";

useHead({
  bodyAttrs: {
    class: "bg-bg1"
  }
})
</script>

<template>
  <landing>
    <Heading/>
    <reward-coin/>
    <features/>
  </landing>
</template>
