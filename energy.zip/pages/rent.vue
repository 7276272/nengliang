<script setup lang="ts">
definePageMeta({
  layout: 'mainpage',
  pageTransition: {
    name: "jump",
    mode: "out-in",
    duration: 250
  }
})

import panel from "~/components/mainpage/rent/panel.vue";
import statistics from "~/components/mainpage/rent/statistics.vue";
import Faq from "~/components/mainpage/faq.vue";

</script>

<template>
    <div class="my-5 w-full flex items-center justify-center text-white">
      <div class="max-w-[500px] flex flex-col items-center justify-center w-full px-4">
        <span class="text-3xl font-bold">Rent Energy</span>
        <span class="text-md text-white/80 mt-1 tracking-wide">TRX Energy(Tron Energy) Rent</span>

        <panel/>
        <statistics class="mt-6"/>
        <faq class="mt-6"/>
      </div>
    </div>
</template>
