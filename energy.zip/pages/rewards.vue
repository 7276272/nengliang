<script setup lang="ts">
import mainpage from "~/layouts/mainpage.vue";
import Footer from "~/components/mainpage/footer.vue";
import Panel from "~/components/mainpage/panel.vue";
import RewardsOverview from "~/components/mainpage/rewardsOverview.vue";
import WalletOverview from "~/components/mainpage/walletOverview.vue";

</script>

<template>
  <mainpage>
    <div class="my-5 w-full flex items-center justify-center text-white">
      <div class="max-w-4xl flex flex-col items-center justify-center w-full px-4">
        <span class="text-2xl font-bold">Reward History</span>
        <span class="text-sm text-white/80 mt-1">Earn rewards with energy rent</span>

        <div class="mt-6 flex flex-col w-full">
          <panel class="bg-[#44444D] translate-y-4 pt-8 pb-10 flex justify-center items-center rounded-bl-none rounded-br-none">
            <span class="text-sm text-neutral-200">Connect your wallet to view your rewards</span>
          </panel>
<!--          <wallet-overview balance-only/>-->
          <rewards-overview class="z-10"/>
        </div>

        <panel class="mt-6">
          <span class="text-[14px] font-bold">Reward history</span>

          <div class="flex flex-col py-9 justify-center items-center">
            <span class="text-[12px] text-neutral-200">You don't have staked tokens. Stake now and receive daily rewards.</span>
            <button
                class="mt-4 text-shadow text-sm bg-accent-cyan rounded-lg text-white font-semibold px-4 min-w-max py-1.5 transition-colors hover:bg-accent-ocean">
              Stake now
            </button>
          </div>
        </panel>

      </div>
    </div>

  </mainpage>
</template>
