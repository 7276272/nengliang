import { defineRule } from 'vee-validate';
import {required, max, numeric, min_value, min, email} from '@vee-validate/rules'
import {localize, setLocale} from '@vee-validate/i18n';
//Define rules here
export default defineNuxtPlugin(nuxtApp => {
    setLocale('en');
    defineRule('required', required);
    defineRule('max', max);
    defineRule('numeric', numeric);
    defineRule('min_value', min_value);
    defineRule('min', min);
    defineRule('email', email);

    defineRule('confirmed', (value, [target], ctx) => {
        if (value === ctx.form[target]) {
            return true;
        }
        return 'Passwords are not the same.';
    });
})