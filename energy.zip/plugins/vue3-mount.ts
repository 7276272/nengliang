import Vue3Mount from 'vue3-mount'
export default defineNuxtPlugin(nuxtApp => {
        nuxtApp.vueApp.use(Vue3Mount)
})