import { compare } from 'bcrypt';
import { readFileSync } from 'fs';

const usersFile = 'data/users.json';

export default defineEventHandler(async (event) => {
    const body = await readBody(event);
    const { username, password } = body;

    // Load users from file
    const users = JSON.parse(readFileSync(usersFile, 'utf-8'));

    // Find the user
    const user = users.find(user => user.username === username);

    if (!user) {
        return { error: 'User not found' };
    }

    // Compare the password
    const passwordMatch = await compare(password, user.passwordHash);

    if (!passwordMatch) {
        return { error: 'Invalid password' };
    }

    await setUserSession(event, {
        user: {
            login: username
        },
        secure: {
            apiToken: '1234567890'
        },
        loggedInAt: new Date()
    })


    return { success: true};
});