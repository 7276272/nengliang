import { hash } from 'bcrypt';
import { readFileSync, writeFileSync } from 'fs';

const usersFile = 'data/users.json';

export default defineEventHandler(async (event) => {
    const body = await readBody(event);
    const { username, password } = body;

    // Load current users
    const users = JSON.parse(readFileSync(usersFile, 'utf-8'));

    // Check if the user already exists
    if (users.find(user => user.username === username)) {
        return { error: 'User already exists' };
    }

    // Hash the password
    const passwordHash = await hash(password, 10);

    // Add new user
    users.push({ username, passwordHash });

    // Save users back to the file
    writeFileSync(usersFile, JSON.stringify(users, null, 2));

    return { success: true };
});