import {defineStore} from 'pinia'

export const useAuthStore = defineStore('auth-store', () => {
    const $alert = useAlert()
    const $user = ref(null);

    const makeAuth = async (form) => {
        const {success}  = await $fetch("/api/login", {
            method: "POST",
            body: JSON.stringify({
                username: form.email,
                password: form.password
            }),
            headers: {
                'Content-Type': 'application/json',
            }
        })

        if(!success) {
            $alert({
                type: "error",
                content: "Incorrect e-mail address or password.",
                expire: true,
                expireDuration: 2500
            });

            return
        }

        $alert({
            type: "success",
            content: "Successfully logged in.",
            expire: true,
            expireDuration: 1500,
        });

        setTimeout(() => navigateTo('/rent', {external: true}), 1500)
    }

    const makeRegister = async (form) => {
        const {success, error} = await $fetch("/api/register", {
            method: "POST",
            body: JSON.stringify({
                username: form.email,
                password: form.password
            }),
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        })

        if(error) {
            $alert({
                type: "error",
                content: error,
                expire: true,
                expireDuration: 3500
            });

            return
        }

        if(!success) {
            $alert({
                type: "error",
                content: "Couldn't create account at this time. Try again later",
                expire: true,
                expireDuration: 3500
            });

            return
        }

        $alert({
            type: "success",
            content: "Successfully registered. You can now login in your account.",
            expire: true,
            expireDuration: 1500
        });

        setTimeout(() => navigateTo('/auth/login'), 1500)
    }

    const logout = () => {

    }

    return {
        makeAuth,
        makeRegister
    }
})