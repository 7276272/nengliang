import { defineStore } from 'pinia'

export const useLandingUIStore = defineStore('landing-ui-store', () => {
    const floatingNavigationOpen = ref(false);


    return {floatingNavigationOpen}
});
