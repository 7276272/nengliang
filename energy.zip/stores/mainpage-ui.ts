import { defineStore } from 'pinia'
export const useMainPageUIStore = defineStore('mainpage-ui-store', () => {
    const route = useRoute();
    const routeName = ref<String>(route.name);

    const routes = [
        {
            pathName : 'rent',
            name: 'RENT ENERGY',
            svg: `<svg width="21" height="21" viewBox="0 0 24 24" fill="currentColor" data-testid="navStake"><path fill-rule="evenodd" clip-rule="evenodd" d="M18.988 9.05a1 1 0 01.89.55 1 1 0 01-.08 1.04l-8 11a1 1 0 01-1.81-.59v-6h-5a1 1 0 01-.89-.64 1 1 0 01.08-1l8-11a1 1 0 011.12-.36 1 1 0 01.69 1v6h5zm-7 5v3.92l5-6.92h-4a1 1 0 01-1-1V6.13l-5 6.92h4a1 1 0 011 1z"></path></svg>`
        },

        {
            pathName : 'rewards',
            name: 'REWARDS',
            svg: `<svg  xmlns="http://www.w3.org/2000/svg"  width="24"  height="24"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="icon icon-tabler icons-tabler-outline icon-tabler-award"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 9m-6 0a6 6 0 1 0 12 0a6 6 0 1 0 -12 0" /><path d="M12 15l3.4 5.89l1.598 -3.233l3.598 .232l-3.4 -5.889" /><path d="M6.802 12l-3.4 5.89l3.598 -.233l1.598 3.232l3.4 -5.889" /></svg>`
        },
    ]

    watch(() => route, () => {
        routeName.value = route.name
    }, {deep: true})

    const currentRoute = computed(() : String => routeName.value);

    const navigate = async (pathName) : Promise<void> => {
        try {
            await navigateTo(pathName)
            routeName.value = pathName;
        } catch(err) {

        }

    }

    return {
        navigate,
        routes,
        currentRoute
    };
});
