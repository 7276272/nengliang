/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./components/**/*.{js,vue,ts}",
    "./layouts/**/*.vue",
    "./pages/**/*.vue",
    "./plugins/**/*.{js,ts}",
    "./app.vue",
    "./error.vue",
  ],
  theme: {
    fontFamily: {
      'sans' : ['Manrope'],
    },

    fontSize: {
      xs: '0.75rem',
      sm: '0.82rem',
      base: '1rem',
      'lg': '17px',
      xl: '1.25rem',
      '2xl': '1.563rem',
      '3xl': '1.953rem',
      '4xl': '2.441rem',
      '5xl': '3.052rem',
    },

    screens: {
      'sm': '640px',
      'md': '768px',
      'lg': '1024px',
      'xl': '1280px',
      '2xl': '1440px',
      '3xl': '1920px',
    },


    extend: {
      backgroundImage: {
        'splash1' : 'radial-gradient(hsla(14,85%,75%,.25) 0,transparent 60%)',
        'splash2' : 'radial-gradient(rgba(255,91,130,.2) 0,transparent 60%)',
        'splash3' : 'radial-gradient(rgba(147,146,255,.2) 0,transparent 60%)',
        'splash4' : 'radial-gradient(rgba(0,179,255,.3) 0,transparent 70%)',
        'splash5' : 'radial-gradient(rgba(0,41,255,.2) 0,transparent 70%)',
        'splash6' : 'radial-gradient(rgba(255,84,248,.25) 0,transparent 60%)',
        'splitterGradient': 'linear-gradient(180deg, rgba(254,248,249,1) 0%, rgba(234,228,229,1) 40%, rgba(234,228,229,1) 50%, rgba(234,228,229,1) 60%, rgba(254,248,249,1) 100%);',
        'splitterGradientHorizontal': 'linear-gradient(90deg, rgba(254,248,249,1) 0%, rgba(234,228,229,1) 20%, rgba(234,228,229,1) 50%, rgba(234,228,229,1) 80%, rgba(254,248,249,1) 100%);',
        'walletOverviewBG': 'linear-gradient(52.01deg, rgb(55, 57, 74) 0%, rgb(54, 55, 73) 0.01%, rgb(64, 80, 79) 100%)',
      },


      colors: {
        'bg1' : '#FEF8F9',
        'bg2' : '#1C1C20',
        'bgPanel' : '#34343d',
        'bgPanelInput' : '#2f2f37',
        'bgPanelPanel' : '#28282F',
        'textSecondary' : 'rgba(255, 255, 255, .8)',

        'accent-ocean' : '#0085ff',
        'accent-cyan' : '#01A3FE',
        'section-splitter': 'rgb(0 0 0 / 8%)',
        'section-splitter-darker': 'rgb(0 0 0 / 15%)',
      }

    },
  },
  plugins: [],
}